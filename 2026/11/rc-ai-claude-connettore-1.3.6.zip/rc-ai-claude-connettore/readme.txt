=== RC AI Claude Connettore ===
Contributors: Rocket Comunicazione
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.3.6
License: GPL-2.0-or-later

Funzioni che il connettore WordPress standard non offre, usate da Claude.

== Descrizione ==

Tutti gli indirizzi sono sotto /wp-json/rc-ai-claude-connettore/v1/ e rispondono solo agli amministratori.

* GET  /info                    Moduli attivi, versioni, indirizzi, token GitHub presente.
* POST /aggiorna                Controlla subito GitHub e aggiorna questo plugin se c'è una versione più alta.
* POST /token {token}           Prova il token su GitHub e lo salva nell'opzione rc_claude_github_token (mai restituito).
* GET  /spazio?ricalcola=0|1    Spazio reale: file, database, Updraft, cache, Imagify, file più grandi.
* GET  /cache?dal=timestamp     Stato della cache WP Rocket in tempo reale.
* POST /cache/svuota {piano_b}  Pulizia completa della cache WP Rocket con verifica.
* GET  /strumenti               Strumenti Easy MCP AI visibili a Claude: stato, elenco base, eccezioni.
* GET  /strumenti/easy-mcp?nome=  Opzioni easy_mcp_ai* (sola lettura, segreti oscurati), per diagnosi.
* POST /strumenti {attivo, aggiungi, rimuovi}  Accende o spegne il filtro; su richiesta elementor, imagify, divi
                                (1 ora dall'ultimo utilizzo, massimo 24 ore).

== Struttura ==

* rc-ai-claude-connettore.php  Intestazione e avvio.
* core/loader.php              Carica ogni file di moduli/ e gestisce attivazione, disattivazione, disinstallazione, /info.
* core/rest.php                Namespace, permessi, registrazione indirizzi.
* core/utilita.php             Misura cartelle, percorsi, date, dimensioni.
* core/aggiornamenti.php       Aggiornamenti automatici dal ramo main del repository GitHub privato.
* vendor/plugin-update-checker Libreria Plugin Update Checker 5.7 (MIT).
* moduli/*.php                 Un file per modulo. Nuovo modulo = nuovo file che chiama RC_Claude_Loader::registra().

== Aggiornamenti ==

Il plugin si aggiorna da solo dal ramo main di github.com/rocketcomunicazione/rc-ai-claude-connettore.
Su ogni sito serve un token GitHub in sola lettura, in uno di questi due modi:
* wp-config.php: define( 'RC_CLAUDE_GITHUB_TOKEN', 'github_pat_...' );
* opzione: wp option update rc_claude_github_token github_pat_... --autoload=no

Per pubblicare una nuova versione: aumentare Version e RC_CLAUDE_VERSIONE, aggiungere il changelog
e caricare su main. I siti la ricevono al controllo successivo (circa ogni 12 ore).
Non creare release né tag: avrebbero la precedenza sul ramo main.

== Changelog ==

= 1.3.6 =
* POST /token: salva il token GitHub nel database dopo averlo provato; non viene mai restituito.

= 1.3.5 =
* POST /aggiorna: controlla subito GitHub (ramo main) e aggiorna il plugin, senza aspettare le 12 ore.
* /info: token GitHub presente (wp-config.php, opzione o mancante) e ultimo controllo.

= 1.3.4 =
* Conferme (Require approval) riportate al default ogni ora: 13 strumenti con conferma, tutti gli altri senza.
  Scrive solo easy_mcp_ai_tool_policy[choices][strumento][requireApproval]; se il formato cambia non scrive niente.

= 1.3.3 =
* WP Rocket tolto dalla lista di default: la cache si svuota con POST /cache/svuota.

= 1.3.2 =
* Lista di default minima, uguale per tutti i siti (Rank Math e Yoast: solo title e description).
* Spenti uno per uno con EASY_MCP_AI_TOOLS gli strumenti che passerebbero per inizio del nome (es. wp_get_post_meta).
* Su richiesta: elementor, imagify, divi. L'eccezione si rinnova a ogni utilizzo e scade 1 ora dopo l'ultimo,
  comunque entro 24 ore dall'accensione.

= 1.3.1 =
* GET /strumenti/easy-mcp: elenco in sola lettura delle opzioni di Easy MCP AI (segreti oscurati).

= 1.3.0 =
* Nuovo modulo Strumenti: elenco base degli strumenti Easy MCP AI tramite EASY_MCP_AI_ALLOWED_TOOL_PATTERNS,
  definita da mu-plugins/rc-claude-strumenti.php. Spento per default, si attiva sito per sito.
  Eccezioni temporanee per sito (default 3 ore). Emergenza: attivo=false o cancellare il file in mu-plugins.
* Nuovo modulo Esclusioni: WP Rocket non mette in cache /wp-json/easy-mcp-ai/, /.well-known/oauth-*,
  /.well-known/openid-configuration (correzione suggerita dalla diagnostica di Easy MCP AI).
* /info: stato della cache degli oggetti, versione Easy MCP AI, stato sintetico di ogni modulo.

= 1.2.0 =
* Aggiornamenti automatici dal ramo main del repository GitHub privato (Plugin Update Checker).
* Aggiornamento automatico sempre attivo per questo plugin.
* Token da costante RC_CLAUDE_GITHUB_TOKEN o da opzione rc_claude_github_token.
* Avviso nella pagina Plugin se manca il token.

= 1.1.0 =
* Riorganizzazione: core/ (loader, rest, utilita) e moduli/ (spazio, cache).
* Nuovo indirizzo /info.

= 1.0.1 =
* Indirizzi spostati sotto rc-ai-claude-connettore/v1.
* Pulizia come il pulsante di WP Rocket: anche minificati e cache busting.
* File Used CSS orfani cancellati; avviso WP Rocket "plugin abilitati o disabilitati" chiuso.
* Verifica: ignora i segnaposto index.html, controlla tutte le cartelle pulite.

= 1.0.0 =
* Prima versione: moduli Spazio (da RC Spazio Disco 1.2) e Cache.
