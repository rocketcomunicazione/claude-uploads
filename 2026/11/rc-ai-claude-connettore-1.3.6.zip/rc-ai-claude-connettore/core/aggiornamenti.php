<?php
/**
 * Aggiornamenti automatici dal repository GitHub privato.
 *
 * Il plugin legge la versione dal ramo main del repository: quando su main c'è una versione più alta,
 * la mostra in Plugin › Plugin installati e la installa da solo (aggiornamento automatico forzato).
 * Non creare release né tag sul repository: avrebbero la precedenza sul ramo main.
 *
 * Serve un token GitHub in sola lettura. Il plugin lo cerca, in quest'ordine:
 *   1. costante in wp-config.php: define( 'RC_CLAUDE_GITHUB_TOKEN', 'github_pat_...' );
 *   2. opzione del database rc_claude_github_token (es. wp option update rc_claude_github_token github_pat_... --autoload=no)
 * Senza token il plugin funziona normalmente, ma non riceve aggiornamenti.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Aggiornamenti {

	const REPOSITORY = 'https://github.com/rocketcomunicazione/rc-ai-claude-connettore/';
	const SLUG       = 'rc-ai-claude-connettore';
	const RAMO       = 'main';

	/** @var object|null Istanza di Plugin Update Checker (null senza token). */
	private static $controllo = null;

	public static function avvia() {
		add_filter( 'auto_update_plugin', array( __CLASS__, 'forza_automatico' ), 10, 2 );
		add_action( 'rest_api_init', array( __CLASS__, 'registra_rest' ) );

		if ( ! self::token() ) {
			add_action( 'admin_notices', array( __CLASS__, 'avviso_token' ) );
			return;
		}

		require_once RC_CLAUDE_DIR . 'vendor/plugin-update-checker/plugin-update-checker.php';

		self::$controllo = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
			self::REPOSITORY,
			RC_CLAUDE_FILE,
			self::SLUG
		);
		self::$controllo->setBranch( self::RAMO );
		self::$controllo->setAuthentication( self::token() );
	}

	/* ---------- Comando di aggiornamento ---------- */

	public static function registra_rest() {
		RC_Claude_Rest::registra( '/aggiorna', 'POST', array( __CLASS__, 'rest_aggiorna' ) );
		RC_Claude_Rest::registra(
			'/token',
			'POST',
			array( __CLASS__, 'rest_token' ),
			array(
				'token' => array(
					'type'        => 'string',
					'required'    => true,
					'description' => 'Token GitHub in sola lettura per il repository del plugin. Salvato nell\'opzione rc_claude_github_token; mai restituito.',
				),
			)
		);
	}

	/**
	 * Salva il token nell'opzione (autoload no) dopo averlo provato su GitHub.
	 * Se in wp-config.php c'è la costante, quella ha la precedenza: lo segnala.
	 */
	public static function rest_token( WP_REST_Request $richiesta ) {
		$token = trim( (string) $richiesta->get_param( 'token' ) );
		if ( ! preg_match( '/^[A-Za-z0-9_]{20,255}$/', $token ) ) {
			return new WP_Error( 'rc_token', 'Formato del token non valido.', array( 'status' => 400 ) );
		}

		$risposta = wp_remote_get(
			'https://api.github.com/repos/rocketcomunicazione/rc-ai-claude-connettore',
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/vnd.github+json',
					'User-Agent'    => 'rc-ai-claude-connettore',
				),
			)
		);
		$codice = is_wp_error( $risposta ) ? 0 : (int) wp_remote_retrieve_response_code( $risposta );
		if ( 200 !== $codice ) {
			return rest_ensure_response(
				array(
					'ok'        => false,
					'salvato'   => false,
					'messaggio' => 'GitHub non accetta il token (risposta ' . ( $codice ? $codice : 'nessuna' ) . '): non salvato.',
				)
			);
		}

		update_option( self::OPZIONE_TOKEN, $token, false );
		$costante = defined( 'RC_CLAUDE_GITHUB_TOKEN' ) && '' !== trim( (string) RC_CLAUDE_GITHUB_TOKEN );

		return rest_ensure_response(
			array(
				'ok'        => true,
				'salvato'   => true,
				'messaggio' => $costante
					? 'Token valido e salvato, ma wp-config.php ne definisce già uno: vale quello.'
					: 'Token valido e salvato. Il comando /aggiorna è attivo dalla prossima richiesta.',
			)
		);
	}

	/**
	 * Controlla subito GitHub (ramo main) e, se c'è una versione più alta, aggiorna questo plugin
	 * come fa WordPress con "Aggiorna ora". Il plugin resta attivo.
	 */
	public static function rest_aggiorna() {
		if ( ! self::$controllo ) {
			return rest_ensure_response(
				array(
					'ok'        => false,
					'versione'  => RC_CLAUDE_VERSIONE,
					'messaggio' => 'Token GitHub mancante: aggiornamento impossibile da GitHub su questo sito.',
				)
			);
		}

		$prima  = RC_CLAUDE_VERSIONE;
		$update = self::$controllo->checkForUpdates();
		if ( ! $update ) {
			return rest_ensure_response(
				array(
					'ok'        => true,
					'aggiornato' => false,
					'versione'  => $prima,
					'messaggio' => 'Già all\'ultima versione di GitHub.',
				)
			);
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		if ( ! class_exists( 'WP_Ajax_Upgrader_Skin' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
		}

		$file      = plugin_basename( RC_CLAUDE_FILE );
		$skin      = new WP_Ajax_Upgrader_Skin();
		$upgrader  = new Plugin_Upgrader( $skin );
		$risultato = $upgrader->upgrade( $file );

		$errori = $skin->get_errors();
		$ok     = true === $risultato && ! ( is_wp_error( $errori ) && $errori->has_errors() );
		$dati   = get_file_data( WP_PLUGIN_DIR . '/' . $file, array( 'Version' => 'Version' ) );

		return rest_ensure_response(
			array(
				'ok'          => $ok,
				'aggiornato'  => $ok,
				'da'          => $prima,
				'a'           => $dati['Version'] ?: null,
				'disponibile' => $update->version,
				'attivo'      => is_plugin_active( $file ),
				'messaggi'    => array_slice( array_map( 'wp_strip_all_tags', (array) $skin->get_upgrade_messages() ), -10 ),
				'errori'      => is_wp_error( $errori ) ? $errori->get_error_messages() : array(),
			)
		);
	}

	/** Per /info. */
	public static function stato() {
		$origine = 'mancante';
		if ( defined( 'RC_CLAUDE_GITHUB_TOKEN' ) && is_string( RC_CLAUDE_GITHUB_TOKEN ) && '' !== trim( RC_CLAUDE_GITHUB_TOKEN ) ) {
			$origine = 'wp-config.php';
		} elseif ( self::token() ) {
			$origine = 'opzione';
		}
		$ultimo = null;
		if ( self::$controllo ) {
			$ultimo = RC_Claude_Utilita::data( (int) self::$controllo->getUpdateState()->getLastCheck() );
		}
		return array(
			'token'           => $origine,
			'ultimo_controllo' => $ultimo,
			'comando'         => 'POST /aggiorna',
		);
	}

	const OPZIONE_TOKEN = 'rc_claude_github_token';

	/** Token dalla costante in wp-config.php o, in alternativa, dall'opzione; stringa vuota se manca. */
	private static function token() {
		if ( defined( 'RC_CLAUDE_GITHUB_TOKEN' ) && is_string( RC_CLAUDE_GITHUB_TOKEN ) && '' !== trim( RC_CLAUDE_GITHUB_TOKEN ) ) {
			return trim( RC_CLAUDE_GITHUB_TOKEN );
		}
		$opzione = get_option( self::OPZIONE_TOKEN, '' );
		return is_string( $opzione ) ? trim( $opzione ) : '';
	}

	/** Attiva sempre l'aggiornamento automatico per questo plugin. */
	public static function forza_automatico( $aggiorna, $elemento ) {
		if ( isset( $elemento->plugin ) && plugin_basename( RC_CLAUDE_FILE ) === $elemento->plugin ) {
			return true;
		}
		return $aggiorna;
	}

	/** Avviso nella pagina Plugin, solo per gli amministratori, se manca il token. */
	public static function avviso_token() {
		$schermata = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $schermata || 'plugins' !== $schermata->id || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>'
			. esc_html__( 'RC AI Claude Connettore: per ricevere gli aggiornamenti automatici aggiungi il token GitHub (costante RC_CLAUDE_GITHUB_TOKEN in wp-config.php oppure opzione rc_claude_github_token).', 'rc-ai-claude-connettore' )
			. '</p></div>';
	}
}

RC_Claude_Aggiornamenti::avvia();
