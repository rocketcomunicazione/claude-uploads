<?php
/**
 * Carica in automatico ogni file della cartella moduli/ e ne gestisce il ciclo di vita.
 *
 * Per aggiungere un modulo: creare moduli/nome.php con una classe e, in fondo al file,
 * RC_Claude_Loader::registra( array( 'id', 'classe', 'versione', 'descrizione', 'indirizzi' ) ).
 * La classe può avere i metodi statici avvia, attivazione, disattivazione, disinstallazione.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Loader {

	/** @var array Moduli registrati, per id. */
	private static $moduli = array();

	public static function registra( array $modulo ) {
		self::$moduli[ $modulo['id'] ] = wp_parse_args(
			$modulo,
			array( 'versione' => '1.0', 'descrizione' => '', 'indirizzi' => array() )
		);
	}

	public static function carica() {
		$file = glob( RC_CLAUDE_DIR . 'moduli/*.php' );
		foreach ( is_array( $file ) ? $file : array() as $percorso ) {
			require_once $percorso;
		}
		ksort( self::$moduli );

		self::chiama( 'avvia' );
		add_action( 'rest_api_init', array( __CLASS__, 'registra_rest' ) );
	}

	public static function registra_rest() {
		RC_Claude_Rest::registra( '/info', 'GET', array( __CLASS__, 'info' ) );
	}

	/** Elenco dei moduli attivi, con versione e indirizzi. */
	public static function info() {
		$moduli = array();
		foreach ( self::$moduli as $m ) {
			$moduli[] = array(
				'id'          => $m['id'],
				'versione'    => $m['versione'],
				'descrizione' => $m['descrizione'],
				'indirizzi'   => $m['indirizzi'],
			);
		}

		return rest_ensure_response(
			array(
				'plugin'    => 'RC AI Claude Connettore',
				'versione'  => RC_CLAUDE_VERSIONE,
				'namespace' => RC_Claude_Rest::NS,
				'wordpress' => get_bloginfo( 'version' ),
				'php'       => PHP_VERSION,
				'moduli'    => $moduli,
			)
		);
	}

	public static function attivazione() {
		self::chiama( 'attivazione' );
	}

	public static function disattivazione() {
		self::chiama( 'disattivazione' );
	}

	public static function disinstallazione() {
		self::chiama( 'disinstallazione' );
	}

	private static function chiama( $metodo ) {
		foreach ( self::$moduli as $m ) {
			if ( method_exists( $m['classe'], $metodo ) ) {
				call_user_func( array( $m['classe'], $metodo ) );
			}
		}
	}
}
