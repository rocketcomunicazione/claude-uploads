<?php
/**
 * Aggiornamenti automatici dal repository GitHub privato.
 *
 * Il plugin legge la versione dal ramo main del repository: quando su main c'è una versione più alta,
 * la mostra in Plugin › Plugin installati e la installa da solo (aggiornamento automatico forzato).
 * Non creare release né tag sul repository: avrebbero la precedenza sul ramo main.
 *
 * Serve un token GitHub in sola lettura. Il plugin lo cerca, in quest'ordine:
 *   1. costante in wp-config.php: define( 'RC_CLAUDE_GITHUB_TOKEN', 'github_pat_...' );
 *   2. opzione del database rc_claude_github_token (es. wp option update rc_claude_github_token github_pat_... --autoload=no)
 * Senza token il plugin funziona normalmente, ma non riceve aggiornamenti.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Aggiornamenti {

	const REPOSITORY = 'https://github.com/rocketcomunicazione/rc-ai-claude-connettore/';
	const SLUG       = 'rc-ai-claude-connettore';
	const RAMO       = 'main';

	public static function avvia() {
		add_filter( 'auto_update_plugin', array( __CLASS__, 'forza_automatico' ), 10, 2 );

		if ( ! self::token() ) {
			add_action( 'admin_notices', array( __CLASS__, 'avviso_token' ) );
			return;
		}

		require_once RC_CLAUDE_DIR . 'vendor/plugin-update-checker/plugin-update-checker.php';

		$controllo = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
			self::REPOSITORY,
			RC_CLAUDE_FILE,
			self::SLUG
		);
		$controllo->setBranch( self::RAMO );
		$controllo->setAuthentication( self::token() );
	}

	const OPZIONE_TOKEN = 'rc_claude_github_token';

	/** Token dalla costante in wp-config.php o, in alternativa, dall'opzione; stringa vuota se manca. */
	private static function token() {
		if ( defined( 'RC_CLAUDE_GITHUB_TOKEN' ) && is_string( RC_CLAUDE_GITHUB_TOKEN ) && '' !== trim( RC_CLAUDE_GITHUB_TOKEN ) ) {
			return trim( RC_CLAUDE_GITHUB_TOKEN );
		}
		$opzione = get_option( self::OPZIONE_TOKEN, '' );
		return is_string( $opzione ) ? trim( $opzione ) : '';
	}

	/** Attiva sempre l'aggiornamento automatico per questo plugin. */
	public static function forza_automatico( $aggiorna, $elemento ) {
		if ( isset( $elemento->plugin ) && plugin_basename( RC_CLAUDE_FILE ) === $elemento->plugin ) {
			return true;
		}
		return $aggiorna;
	}

	/** Avviso nella pagina Plugin, solo per gli amministratori, se manca il token. */
	public static function avviso_token() {
		$schermata = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $schermata || 'plugins' !== $schermata->id || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>'
			. esc_html__( 'RC AI Claude Connettore: per ricevere gli aggiornamenti automatici aggiungi il token GitHub (costante RC_CLAUDE_GITHUB_TOKEN in wp-config.php oppure opzione rc_claude_github_token).', 'rc-ai-claude-connettore' )
			. '</p></div>';
	}
}

RC_Claude_Aggiornamenti::avvia();
