=== RC AI Claude Connettore ===
Contributors: Rocket Comunicazione
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPL-2.0-or-later

Funzioni che il connettore WordPress standard non offre, usate da Claude.

== Descrizione ==

Tutti gli indirizzi sono sotto /wp-json/rc-ai-claude-connettore/v1/ e rispondono solo agli amministratori.

* GET  /info                    Moduli attivi, versioni e indirizzi.
* GET  /spazio?ricalcola=0|1    Spazio reale: file, database, Updraft, cache, Imagify, file più grandi.
* GET  /cache?dal=timestamp     Stato della cache WP Rocket in tempo reale.
* POST /cache/svuota {piano_b}  Pulizia completa della cache WP Rocket con verifica.

== Struttura ==

* rc-ai-claude-connettore.php  Intestazione e avvio.
* core/loader.php              Carica ogni file di moduli/ e gestisce attivazione, disattivazione, disinstallazione, /info.
* core/rest.php                Namespace, permessi, registrazione indirizzi.
* core/utilita.php             Misura cartelle, percorsi, date, dimensioni.
* core/aggiornamenti.php       Aggiornamenti automatici dal ramo main del repository GitHub privato.
* vendor/plugin-update-checker Libreria Plugin Update Checker 5.7 (MIT).
* moduli/*.php                 Un file per modulo. Nuovo modulo = nuovo file che chiama RC_Claude_Loader::registra().

== Aggiornamenti ==

Il plugin si aggiorna da solo dal ramo main di github.com/rocketcomunicazione/rc-ai-claude-connettore.
Su ogni sito serve un token GitHub in sola lettura in wp-config.php:
define( 'RC_CLAUDE_GITHUB_TOKEN', 'github_pat_...' );

Per pubblicare una nuova versione: aumentare Version e RC_CLAUDE_VERSIONE, aggiungere il changelog
e caricare su main. I siti la ricevono al controllo successivo (circa ogni 12 ore).
Non creare release né tag: avrebbero la precedenza sul ramo main.

== Changelog ==

= 1.2.0 =
* Aggiornamenti automatici dal ramo main del repository GitHub privato (Plugin Update Checker).
* Aggiornamento automatico sempre attivo per questo plugin.
* Avviso nella pagina Plugin se manca il token.

= 1.1.0 =
* Riorganizzazione: core/ (loader, rest, utilita) e moduli/ (spazio, cache).
* Nuovo indirizzo /info.

= 1.0.1 =
* Indirizzi spostati sotto rc-ai-claude-connettore/v1.
* Pulizia come il pulsante di WP Rocket: anche minificati e cache busting.
* File Used CSS orfani cancellati; avviso WP Rocket "plugin abilitati o disabilitati" chiuso.
* Verifica: ignora i segnaposto index.html, controlla tutte le cartelle pulite.

= 1.0.0 =
* Prima versione: moduli Spazio (da RC Spazio Disco 1.2) e Cache.
