<?php
/**
 * Modulo Spazio: misura reale dello spazio del sito.
 * Updraft in tempo reale; tutto il resto calcolato ogni 2 ore (o su richiesta con ?ricalcola=1).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Spazio {

	const OPZIONE       = 'rc_claude_spazio_periodico';
	const HOOK          = 'rc_claude_spazio_calcolo';
	const INTERVALLO    = 'rc_claude_2h';
	const LIMITE_SEC    = 10;
	const LIMITE_MEDIA  = 30;
	const SOGLIA_GRANDI = 5242880; // 5 MB
	const MAX_GRANDI    = 20;

	const WP_CONTENT_ALTROVE  = array( 'plugins', 'themes', 'uploads', 'fonts', 'cache' );
	const ESTENSIONI_SOSPETTE = array( 'zip', 'tar', 'gz', 'tgz', 'rar', '7z', 'sql', 'bak', 'old', 'log', 'wpress', 'daf' );

	/** @var array File più grandi raccolti durante il calcolo. */
	private static $grandi = array();

	/* ---------- Ciclo di vita ---------- */

	public static function avvia() {
		add_filter( 'cron_schedules', array( __CLASS__, 'intervalli_cron' ) );
		add_action( self::HOOK, array( __CLASS__, 'calcolo_periodico' ) );
		add_action( 'init', array( __CLASS__, 'assicura_cron' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'registra_rest' ) );
	}

	public static function intervalli_cron( $intervalli ) {
		$intervalli[ self::INTERVALLO ] = array(
			'interval' => 2 * HOUR_IN_SECONDS,
			'display'  => 'Ogni 2 ore (RC AI Claude Connettore)',
		);
		return $intervalli;
	}

	public static function assicura_cron() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::INTERVALLO, self::HOOK );
		}
	}

	public static function attivazione() {
		self::assicura_cron();
		self::calcolo_periodico();
	}

	public static function disattivazione() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public static function disinstallazione() {
		wp_clear_scheduled_hook( self::HOOK );
		delete_option( self::OPZIONE );
	}

	/* ---------- REST ---------- */

	public static function registra_rest() {
		RC_Claude_Rest::registra(
			'/spazio',
			'GET',
			array( __CLASS__, 'risposta_rest' ),
			array(
				'ricalcola' => array(
					'type'        => 'boolean',
					'default'     => false,
					'description' => 'Ricalcola subito invece di usare il dato delle ultime 2 ore.',
				),
			)
		);
	}

	public static function risposta_rest( WP_REST_Request $richiesta ) {
		$periodico = get_option( self::OPZIONE );
		if ( $richiesta->get_param( 'ricalcola' ) || ! is_array( $periodico ) || ( $periodico['versione'] ?? '' ) !== RC_CLAUDE_VERSIONE ) {
			$periodico = self::calcolo_periodico();
		}

		$updraft  = self::updraft();
		$prossimo = wp_next_scheduled( self::HOOK );

		// "WP": root + wp-content esclusi plugin, temi, uploads, font. Comprende cache e Updraft (se in wp-content).
		$wp = $periodico['root']['byte']
			+ $periodico['wp_content']['byte']
			+ $periodico['cache']['byte']
			+ ( $updraft['dentro_wp_content'] ? $updraft['byte'] : 0 );

		$updraft_fuori = $updraft['dentro_wp_content'] ? 0 : $updraft['byte'];
		$font          = $periodico['font']['dentro_media'] ? 0 : $periodico['font']['byte'];
		$totale_file   = $wp + $updraft_fuori + $periodico['temi']['byte'] + $periodico['plugin']['byte'] + $periodico['media']['byte'] + $font;
		$database      = $periodico['database']['byte'];

		$riepilogo = array(
			'wp_resto'      => RC_Claude_Utilita::voce( $wp ),
			'updraft'       => RC_Claude_Utilita::voce( $updraft['byte'] ),
			'cache'         => RC_Claude_Utilita::voce( $periodico['cache']['byte'] ),
			'temi'          => RC_Claude_Utilita::voce( $periodico['temi']['byte'] ),
			'plugin'        => RC_Claude_Utilita::voce( $periodico['plugin']['byte'] ),
			'media'         => RC_Claude_Utilita::voce( $periodico['media']['byte'] ),
			'font'          => RC_Claude_Utilita::voce( $font ),
			'database'      => RC_Claude_Utilita::voce( $database ),
			'totale_file'   => RC_Claude_Utilita::voce( $totale_file ),
			'totale_con_db' => RC_Claude_Utilita::voce( $totale_file + $database ),
			'completo'      => $periodico['completo'] && $updraft['completo'],
			'note'          => 'wp_resto comprende cache e updraft (se in wp-content). totale_file esclude il database; totale_con_db lo include. Email escluse.',
		);

		return rest_ensure_response(
			array(
				'versione_plugin'   => RC_CLAUDE_VERSIONE,
				'generato_il'       => wp_date( 'd/m/Y H:i:s' ),
				'fuso_orario_sito'  => wp_timezone_string(),
				'riepilogo'         => $riepilogo,
				'updraft'           => $updraft,
				'temi'              => $periodico['temi'],
				'plugin'            => $periodico['plugin'],
				'media'             => $periodico['media'],
				'font'              => $periodico['font'],
				'database'          => $periodico['database'],
				'cache'             => $periodico['cache'],
				'wp_content'        => $periodico['wp_content'],
				'root'              => $periodico['root'],
				'imagify'           => $periodico['imagify'],
				'file_grandi'       => $periodico['file_grandi'],
				'calcolo_periodico' => array(
					'calcolato_il' => $periodico['calcolato_il'],
					'secondi'      => $periodico['secondi'],
					'prossimo'     => RC_Claude_Utilita::data( $prossimo, 'd/m/Y H:i' ),
				),
			)
		);
	}

	/* ---------- UpdraftPlus (tempo reale) ---------- */

	private static function cartella_updraft() {
		$opzione = get_option( 'updraft_dir' );
		$dir     = ( is_string( $opzione ) && '' !== trim( $opzione ) ) ? trim( $opzione ) : 'updraft';
		if ( ! path_is_absolute( $dir ) ) {
			$dir = trailingslashit( WP_CONTENT_DIR ) . ltrim( $dir, '/' );
		}
		return untrailingslashit( wp_normalize_path( $dir ) );
	}

	public static function updraft() {
		$dir = self::cartella_updraft();

		$servizi = get_option( 'updraft_service' );
		$servizi = is_array( $servizi ) ? $servizi : ( $servizi ? array( $servizi ) : array() );
		$servizi = array_values( array_filter( $servizi, static function ( $s ) {
			return is_string( $s ) && '' !== $s && 'none' !== $s;
		} ) );

		$esito = array(
			'plugin_attivo'     => class_exists( 'UpdraftPlus' ) || defined( 'UPDRAFTPLUS_DIR' ),
			'cartella'          => RC_Claude_Utilita::percorso_relativo( $dir ),
			'dentro_wp_content' => 0 === strpos( $dir, RC_Claude_Utilita::wp_content() . '/' ),
			'esiste'            => is_dir( $dir ),
			'storage_remoto'    => $servizi,
			'solo_locale'       => empty( $servizi ),
			'byte'              => 0,
			'dimensione'        => RC_Claude_Utilita::dimensione( 0 ),
			'file'              => 0,
			'backup'            => 0,
			'ultimo_backup'     => null,
			'primo_backup'      => null,
			'elenco_backup'     => array(),
			'log_byte'          => 0,
			'completo'          => true,
		);

		if ( ! $esito['esiste'] ) {
			return $esito;
		}

		$m                   = RC_Claude_Utilita::misura( $dir, microtime( true ) + self::LIMITE_SEC );
		$esito['byte']       = $m['byte'];
		$esito['dimensione'] = RC_Claude_Utilita::dimensione( $m['byte'] );
		$esito['file']       = $m['file'];
		$esito['completo']   = $m['completo'];

		$gruppi = array();
		$voci   = @scandir( $dir );
		foreach ( is_array( $voci ) ? $voci : array() as $nome ) {
			$percorso = $dir . '/' . $nome;
			if ( ! is_file( $percorso ) ) {
				continue;
			}
			$byte = (int) @filesize( $percorso );
			if ( preg_match( '/^backup_(\d{4}-\d{2}-\d{2}-\d{4})_.*_([0-9a-f]{12})-/i', $nome, $x ) ) {
				if ( ! isset( $gruppi[ $x[2] ] ) ) {
					$gruppi[ $x[2] ] = array( 'timbro' => $x[1], 'file' => 0, 'byte' => 0 );
				}
				$gruppi[ $x[2] ]['file']++;
				$gruppi[ $x[2] ]['byte'] += $byte;
			} elseif ( 0 === strpos( $nome, 'log.' ) ) {
				$esito['log_byte'] += $byte;
			}
		}

		uasort( $gruppi, static function ( $a, $b ) {
			return strcmp( $b['timbro'], $a['timbro'] );
		} );

		foreach ( $gruppi as $g ) {
			$data                     = DateTime::createFromFormat( 'Y-m-d-Hi', $g['timbro'], wp_timezone() );
			$esito['elenco_backup'][] = array(
				'data'       => $data ? $data->format( 'd/m/Y H:i' ) : $g['timbro'],
				'file'       => $g['file'],
				'byte'       => $g['byte'],
				'dimensione' => RC_Claude_Utilita::dimensione( $g['byte'] ),
			);
		}

		$esito['backup'] = count( $esito['elenco_backup'] );
		if ( $esito['backup'] ) {
			$esito['ultimo_backup'] = $esito['elenco_backup'][0]['data'];
			$esito['primo_backup']  = $esito['elenco_backup'][ $esito['backup'] - 1 ]['data'];
		}

		return $esito;
	}

	/* ---------- Calcolo periodico ---------- */

	public static function calcolo_periodico() {
		$inizio       = microtime( true );
		self::$grandi = array();
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 );
		}

		$uploads = wp_get_upload_dir();

		$dati = array(
			'versione'   => RC_CLAUDE_VERSIONE,
			'temi'       => self::cartella( get_theme_root(), self::LIMITE_SEC ),
			'plugin'     => self::cartella( WP_PLUGIN_DIR, self::LIMITE_SEC ),
			'media'      => self::cartella( $uploads['basedir'], self::LIMITE_MEDIA ),
			'font'       => self::font( $uploads['basedir'] ),
			'database'   => self::database(),
			'cache'      => self::cache(),
			'wp_content' => self::wp_content(),
			'root'       => self::root(),
			'imagify'    => self::imagify(),
		);

		$dati['completo'] = $dati['temi']['completo'] && $dati['plugin']['completo'] && $dati['media']['completo']
			&& $dati['cache']['completo'] && $dati['wp_content']['completo'] && $dati['root']['completo'];

		usort( self::$grandi, array( 'RC_Claude_Utilita', 'ordina_per_byte' ) );
		$dati['file_grandi']  = array_slice( self::$grandi, 0, self::MAX_GRANDI );
		$dati['calcolato_il'] = wp_date( 'd/m/Y H:i' );
		$dati['secondi']      = number_format( microtime( true ) - $inizio, 2, '.', '' );

		update_option( self::OPZIONE, $dati, false );
		return $dati;
	}

	private static function cartella( $dir, $limite ) {
		$dir   = untrailingslashit( wp_normalize_path( (string) $dir ) );
		$esito = array(
			'cartella'   => RC_Claude_Utilita::percorso_relativo( $dir ),
			'esiste'     => '' !== $dir && is_dir( $dir ),
			'byte'       => 0,
			'dimensione' => RC_Claude_Utilita::dimensione( 0 ),
			'file'       => 0,
			'completo'   => true,
		);
		if ( $esito['esiste'] ) {
			$m                   = RC_Claude_Utilita::misura( $dir, microtime( true ) + $limite );
			$esito['byte']       = $m['byte'];
			$esito['dimensione'] = RC_Claude_Utilita::dimensione( $m['byte'] );
			$esito['file']       = $m['file'];
			$esito['completo']   = $m['completo'];
		}
		return $esito;
	}

	private static function font( $uploads_dir ) {
		if ( function_exists( 'wp_get_font_dir' ) ) {
			$info = wp_get_font_dir();
			$dir  = isset( $info['basedir'] ) ? $info['basedir'] : '';
		} else {
			$dir = trailingslashit( WP_CONTENT_DIR ) . 'fonts';
		}
		$dir     = untrailingslashit( wp_normalize_path( (string) $dir ) );
		$uploads = untrailingslashit( wp_normalize_path( (string) $uploads_dir ) );

		$esito                 = self::cartella( $dir, self::LIMITE_SEC );
		$esito['dentro_media'] = '' !== $uploads && 0 === strpos( $dir . '/', $uploads . '/' );
		return $esito;
	}

	private static function database() {
		global $wpdb;

		$righe = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT TABLE_NAME AS nome, (DATA_LENGTH + INDEX_LENGTH) AS byte, DATA_FREE AS liberabile, TABLE_ROWS AS righe
				FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s',
				DB_NAME
			),
			ARRAY_A
		);

		$esito = array(
			'byte'            => 0,
			'dimensione'      => RC_Claude_Utilita::dimensione( 0 ),
			'byte_sito'       => 0,
			'tabelle'         => 0,
			'liberabile'      => 0,
			'tabelle_pesanti' => array(),
			'letto'           => is_array( $righe ),
		);

		if ( ! is_array( $righe ) ) {
			return $esito;
		}

		$elenco = array();
		foreach ( $righe as $r ) {
			$byte                 = (int) $r['byte'];
			$esito['byte']       += $byte;
			$esito['liberabile'] += (int) $r['liberabile'];
			$esito['tabelle']++;
			if ( 0 === strpos( $r['nome'], $wpdb->prefix ) ) {
				$esito['byte_sito'] += $byte;
			}
			$elenco[] = array(
				'nome'       => $r['nome'],
				'byte'       => $byte,
				'dimensione' => RC_Claude_Utilita::dimensione( $byte ),
				'righe'      => (int) $r['righe'],
			);
		}

		usort( $elenco, array( 'RC_Claude_Utilita', 'ordina_per_byte' ) );
		$esito['tabelle_pesanti']       = array_slice( $elenco, 0, 10 );
		$esito['dimensione']            = RC_Claude_Utilita::dimensione( $esito['byte'] );
		$esito['dimensione_sito']       = RC_Claude_Utilita::dimensione( $esito['byte_sito'] );
		$esito['dimensione_liberabile'] = RC_Claude_Utilita::dimensione( $esito['liberabile'] );
		return $esito;
	}

	private static function cache() {
		$dir   = RC_Claude_Utilita::wp_content() . '/cache';
		$esito = array(
			'cartella'   => RC_Claude_Utilita::percorso_relativo( $dir ),
			'esiste'     => is_dir( $dir ),
			'byte'       => 0,
			'dimensione' => RC_Claude_Utilita::dimensione( 0 ),
			'file'       => 0,
			'dettaglio'  => array(),
			'completo'   => true,
		);
		if ( ! $esito['esiste'] ) {
			return $esito;
		}

		$voci                = self::elenca( $dir, microtime( true ) + self::LIMITE_SEC, true );
		$esito['dettaglio']  = $voci['cartelle'];
		$esito['byte']       = $voci['byte'];
		$esito['file']       = $voci['file'];
		$esito['completo']   = $voci['completo'];
		$esito['dimensione'] = RC_Claude_Utilita::dimensione( $esito['byte'] );
		return $esito;
	}

	private static function wp_content() {
		$base    = RC_Claude_Utilita::wp_content();
		$escluse = self::WP_CONTENT_ALTROVE;
		$updraft = self::cartella_updraft();
		if ( dirname( $updraft ) === $base ) {
			$escluse[] = basename( $updraft );
		}

		$voci = self::elenca( $base, microtime( true ) + self::LIMITE_SEC, true, $escluse );

		return array(
			'nota'         => 'Tutte le cartelle di wp-content tranne plugins, themes, uploads, fonts, cache e updraft (misurate a parte).',
			'byte'         => $voci['byte'],
			'dimensione'   => RC_Claude_Utilita::dimensione( $voci['byte'] ),
			'cartelle'     => $voci['cartelle'],
			'file_sciolti' => $voci['sciolti'],
			'completo'     => $voci['completo'],
		);
	}

	private static function root() {
		$base    = untrailingslashit( wp_normalize_path( ABSPATH ) );
		$content = RC_Claude_Utilita::wp_content();
		$escluse = ( dirname( $content ) === $base ) ? array( basename( $content ) ) : array();

		$voci = self::elenca( $base, microtime( true ) + self::LIMITE_SEC, true, $escluse );

		$sospetti = array();
		$elenco   = @scandir( $base );
		foreach ( is_array( $elenco ) ? $elenco : array() as $nome ) {
			$percorso = $base . '/' . $nome;
			if ( ! is_file( $percorso ) || is_link( $percorso ) ) {
				continue;
			}
			$est = strtolower( pathinfo( $nome, PATHINFO_EXTENSION ) );
			if ( in_array( $est, self::ESTENSIONI_SOSPETTE, true ) || 'error_log' === $nome ) {
				$byte       = (int) @filesize( $percorso );
				$sospetti[] = array(
					'nome'       => $nome,
					'byte'       => $byte,
					'dimensione' => RC_Claude_Utilita::dimensione( $byte ),
					'modificato' => RC_Claude_Utilita::data( @filemtime( $percorso ), 'd/m/Y' ),
				);
			}
		}
		usort( $sospetti, array( 'RC_Claude_Utilita', 'ordina_per_byte' ) );

		return array(
			'nota'          => 'Tutta la root del sito tranne wp-content (wp-admin, wp-includes, altre cartelle, file).',
			'byte'          => $voci['byte'],
			'dimensione'    => RC_Claude_Utilita::dimensione( $voci['byte'] ),
			'cartelle'      => $voci['cartelle'],
			'file_sciolti'  => $voci['sciolti'],
			'file_sospetti' => $sospetti,
			'completo'      => $voci['completo'],
		);
	}

	private static function imagify() {
		$opzioni = get_option( 'imagify_settings' );

		if ( function_exists( 'get_imagify_backup_dir_path' ) ) {
			$dir = get_imagify_backup_dir_path();
		} else {
			$uploads = wp_get_upload_dir();
			$dir     = trailingslashit( $uploads['basedir'] ) . 'backup/';
		}

		$esito                  = self::cartella( $dir, self::LIMITE_SEC );
		$esito['plugin_attivo'] = class_exists( 'Imagify' ) || defined( 'IMAGIFY_VERSION' );
		$esito['backup_attivo'] = is_array( $opzioni ) && ! empty( $opzioni['backup'] );
		return $esito;
	}

	/* ---------- Supporto ---------- */

	/** Sottocartelle di $base con il loro peso, più i file sciolti. */
	private static function elenca( $base, $scadenza, $raccogli_grandi, $escluse = array() ) {
		$esito = array(
			'byte'     => 0,
			'file'     => 0,
			'cartelle' => array(),
			'sciolti'  => array( 'byte' => 0, 'dimensione' => RC_Claude_Utilita::dimensione( 0 ), 'file' => 0 ),
			'completo' => true,
		);

		$per_file = $raccogli_grandi ? array( __CLASS__, 'raccogli_grande' ) : null;

		$voci = @scandir( $base );
		foreach ( is_array( $voci ) ? $voci : array() as $nome ) {
			if ( '.' === $nome || '..' === $nome || in_array( $nome, $escluse, true ) ) {
				continue;
			}
			$percorso = $base . '/' . $nome;
			if ( is_link( $percorso ) ) {
				continue;
			}
			if ( is_dir( $percorso ) ) {
				$m                   = RC_Claude_Utilita::misura( $percorso, $scadenza, $per_file );
				$esito['cartelle'][] = array(
					'nome'       => $nome,
					'byte'       => $m['byte'],
					'dimensione' => RC_Claude_Utilita::dimensione( $m['byte'] ),
					'file'       => $m['file'],
					'completo'   => $m['completo'],
				);
				$esito['byte'] += $m['byte'];
				$esito['file'] += $m['file'];
				if ( ! $m['completo'] ) {
					$esito['completo'] = false;
					break;
				}
			} elseif ( is_file( $percorso ) ) {
				$byte                       = (int) @filesize( $percorso );
				$esito['sciolti']['byte'] += $byte;
				$esito['sciolti']['file']++;
				$esito['byte'] += $byte;
				$esito['file']++;
				if ( $raccogli_grandi ) {
					self::raccogli_grande( new SplFileInfo( $percorso ), $byte );
				}
			}
		}

		usort( $esito['cartelle'], array( 'RC_Claude_Utilita', 'ordina_per_byte' ) );
		$esito['sciolti']['dimensione'] = RC_Claude_Utilita::dimensione( $esito['sciolti']['byte'] );
		return $esito;
	}

	public static function raccogli_grande( $file, $byte ) {
		if ( $byte < self::SOGLIA_GRANDI ) {
			return;
		}
		self::$grandi[] = array(
			'percorso'   => RC_Claude_Utilita::percorso_relativo( $file->getPathname() ),
			'byte'       => $byte,
			'dimensione' => RC_Claude_Utilita::dimensione( $byte ),
			'modificato' => RC_Claude_Utilita::data( $file->getMTime(), 'd/m/Y' ),
		);
	}
}

RC_Claude_Loader::registra(
	array(
		'id'          => 'spazio',
		'classe'      => 'RC_Claude_Spazio',
		'versione'    => '1.2',
		'descrizione' => 'Spazio reale: file, database, Updraft (tempo reale), cache, Imagify, file più grandi. Calcolo ogni 2 ore.',
		'indirizzi'   => array( 'GET /spazio?ricalcola=0|1' ),
	)
);
