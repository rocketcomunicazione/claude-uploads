<?php
/**
 * Carica in automatico ogni file della cartella moduli/ e ne gestisce il ciclo di vita.
 *
 * Per aggiungere un modulo: creare moduli/nome.php con una classe e, in fondo al file,
 * RC_Claude_Loader::registra( array( 'id', 'classe', 'versione', 'descrizione', 'indirizzi' ) ).
 * La classe può avere i metodi statici avvia, attivazione, disattivazione, disinstallazione.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Loader {

	/** @var array Moduli registrati, per id. */
	private static $moduli = array();

	public static function registra( array $modulo ) {
		self::$moduli[ $modulo['id'] ] = wp_parse_args(
			$modulo,
			array( 'versione' => '1.0', 'descrizione' => '', 'indirizzi' => array() )
		);
	}

	public static function carica() {
		$file = glob( RC_CLAUDE_DIR . 'moduli/*.php' );
		foreach ( is_array( $file ) ? $file : array() as $percorso ) {
			require_once $percorso;
		}
		ksort( self::$moduli );

		self::chiama( 'avvia' );
		add_action( 'rest_api_init', array( __CLASS__, 'registra_rest' ) );
	}

	public static function registra_rest() {
		RC_Claude_Rest::registra( '/info', 'GET', array( __CLASS__, 'info' ) );
	}

	/** Elenco dei moduli attivi, con versione e indirizzi. */
	public static function info() {
		$moduli = array();
		foreach ( self::$moduli as $m ) {
			$voce = array(
				'id'          => $m['id'],
				'versione'    => $m['versione'],
				'descrizione' => $m['descrizione'],
				'indirizzi'   => $m['indirizzi'],
			);
			// Stato sintetico del modulo, se lo fornisce.
			if ( method_exists( $m['classe'], 'stato_breve' ) ) {
				$voce['stato'] = call_user_func( array( $m['classe'], 'stato_breve' ) );
			} elseif ( method_exists( $m['classe'], 'stato' ) && 'cache' !== $m['id'] ) {
				$voce['stato'] = call_user_func( array( $m['classe'], 'stato' ) );
			}
			$moduli[] = $voce;
		}

		return rest_ensure_response(
			array(
				'plugin'        => 'RC AI Claude Connettore',
				'versione'      => RC_CLAUDE_VERSIONE,
				'namespace'     => RC_Claude_Rest::NS,
				'wordpress'     => get_bloginfo( 'version' ),
				'php'           => PHP_VERSION,
				'object_cache'  => array(
					'persistente' => (bool) wp_using_ext_object_cache(),
					'drop_in'     => file_exists( WP_CONTENT_DIR . '/object-cache.php' ),
					'memcached'   => class_exists( 'Memcached' ) || class_exists( 'Memcache' ),
				),
				'easy_mcp_ai'   => defined( 'EASY_MCP_AI_VERSION' ) ? EASY_MCP_AI_VERSION : null,
				'aggiornamenti' => class_exists( 'RC_Claude_Aggiornamenti' ) ? RC_Claude_Aggiornamenti::stato() : null,
				'moduli'        => $moduli,
			)
		);
	}

	public static function attivazione() {
		self::chiama( 'attivazione' );
	}

	public static function disattivazione() {
		self::chiama( 'disattivazione' );
	}

	public static function disinstallazione() {
		self::chiama( 'disinstallazione' );
	}

	private static function chiama( $metodo ) {
		foreach ( self::$moduli as $m ) {
			if ( method_exists( $m['classe'], $metodo ) ) {
				call_user_func( array( $m['classe'], $metodo ) );
			}
		}
	}
}
