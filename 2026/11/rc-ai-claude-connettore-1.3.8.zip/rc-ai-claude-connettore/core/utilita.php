<?php
/**
 * Funzioni comuni a tutti i moduli: scansione e misura delle cartelle, percorsi, date e dimensioni.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Utilita {

	// File segnaposto che i plugin lasciano nelle cartelle di cache: non sono contenuti veri.
	const SEGNAPOSTO = array( 'index.html', 'index.php', '.htaccess' );

	/**
	 * Scorre tutti i file di una cartella (link simbolici esclusi) e chiama $fn per ciascuno.
	 * Restituisce false se si ferma per il limite di tempo o per un errore.
	 */
	public static function scorri( $dir, $scadenza, callable $fn ) {
		if ( ! is_dir( $dir ) ) {
			return true;
		}
		try {
			$iteratore = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY,
				RecursiveIteratorIterator::CATCH_GET_CHILD
			);
			foreach ( $iteratore as $file ) {
				if ( microtime( true ) > $scadenza ) {
					return false;
				}
				if ( ! $file->isFile() || $file->isLink() ) {
					continue;
				}
				$fn( $file );
			}
		} catch ( Exception $e ) {
			return false;
		}
		return true;
	}

	/**
	 * Peso e numero di file di una cartella. $per_file( SplFileInfo, byte ) è facoltativa.
	 */
	public static function misura( $dir, $scadenza, $per_file = null ) {
		$esito             = array( 'byte' => 0, 'file' => 0, 'completo' => true );
		$esito['completo'] = self::scorri(
			$dir,
			$scadenza,
			static function ( $file ) use ( &$esito, $per_file ) {
				$byte           = $file->getSize();
				$esito['byte'] += $byte;
				$esito['file']++;
				if ( $per_file ) {
					$per_file( $file, $byte );
				}
			}
		);
		return $esito;
	}

	public static function e_segnaposto( $nome_file ) {
		return in_array( $nome_file, self::SEGNAPOSTO, true );
	}

	public static function wp_content() {
		return untrailingslashit( wp_normalize_path( WP_CONTENT_DIR ) );
	}

	public static function percorso_relativo( $percorso ) {
		$percorso = wp_normalize_path( $percorso );
		$abspath  = wp_normalize_path( ABSPATH );
		return 0 === strpos( $percorso, $abspath ) ? substr( $percorso, strlen( $abspath ) ) : basename( $percorso );
	}

	public static function dimensione( $byte ) {
		return size_format( (int) $byte, 2 );
	}

	public static function voce( $byte ) {
		return array( 'byte' => (int) $byte, 'dimensione' => self::dimensione( $byte ) );
	}

	public static function data( $timestamp, $formato = 'd/m/Y H:i:s' ) {
		return $timestamp ? wp_date( $formato, (int) $timestamp ) : null;
	}

	public static function ordina_per_byte( $a, $b ) {
		return $b['byte'] <=> $a['byte'];
	}
}
