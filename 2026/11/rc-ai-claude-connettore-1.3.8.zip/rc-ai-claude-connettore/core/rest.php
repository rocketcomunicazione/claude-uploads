<?php
/**
 * Regole REST comuni: namespace, permessi e registrazione degli indirizzi.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Rest {

	const NS = 'rc-ai-claude-connettore/v1';

	/** Tutti gli indirizzi rispondono solo agli amministratori. */
	public static function permesso() {
		return current_user_can( 'manage_options' );
	}

	public static function registra( $percorso, $metodi, $callback, $args = array() ) {
		register_rest_route(
			self::NS,
			$percorso,
			array(
				'methods'             => $metodi,
				'callback'            => $callback,
				'permission_callback' => array( __CLASS__, 'permesso' ),
				'args'                => $args,
			)
		);
	}
}
