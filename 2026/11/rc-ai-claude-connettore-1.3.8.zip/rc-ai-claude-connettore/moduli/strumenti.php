<?php
/**
 * Modulo Strumenti: decide quali strumenti di Easy MCP AI vede Claude.
 *
 * Due costanti ufficiali di Easy MCP AI, definite da un piccolo file in mu-plugins
 * (si carica prima di Easy MCP AI e legge l'opzione rc_claude_strumenti):
 * - EASY_MCP_AI_ALLOWED_TOOL_PATTERNS: solo gli strumenti che corrispondono restano disponibili.
 *   Attenzione: Easy MCP AI li confronta come inizio del nome (wp_get_post fa passare anche wp_get_post_meta).
 * - EASY_MCP_AI_TOOLS: "nome=off" spegne singoli strumenti che passerebbero per inizio del nome.
 *
 * Regole:
 * - Lista di default uguale per tutti i siti (costanti BASE e SPENTI). Si cambia aggiornando il plugin.
 * - Spento per default: si attiva sito per sito con POST /strumenti {attivo:true}.
 * - Su richiesta (Elementor, Imagify, Divi o altri modelli): POST /strumenti {aggiungi:"elementor"}.
 *   L'eccezione resta accesa finché Claude la usa: scade 1 ora dopo l'ultimo utilizzo
 *   e comunque 24 ore dopo l'accensione. Poi il sito torna alla lista di default.
 * - Emergenza: POST /strumenti {attivo:false}, oppure cancellare wp-content/mu-plugins/rc-claude-strumenti.php.
 * - Conferme ("Require approval"): ogni ora riportate al default (costante CONFERMA) scrivendo
 *   easy_mcp_ai_tool_policy['choices'][strumento]['requireApproval']; se il formato cambia non scrive niente.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Strumenti {

	const OPZIONE     = 'rc_claude_strumenti';
	const FILE_MU     = 'rc-claude-strumenti.php';
	const VERSIONE_MU = '2';
	const INATTIVITA  = 3600;  // 1 ora dall'ultimo utilizzo.
	const TETTO       = 86400; // 24 ore dall'accensione.

	/** Lista di default: modelli consentiti, uguali per tutti i siti. Un modello senza strumenti sul sito non fa danni. */
	const BASE = array(
		// Articoli e pagine.
		'wp_list_posts',
		'wp_list_pages',
		'wp_get_post',
		'wp_get_page',
		'wp_search_posts',
		'wp_create_post',
		'wp_create_page',
		'wp_update_post',
		'wp_update_page',
		'wp_replace_in_post',
		'wp_create_preview_link',
		'wp_delete_post',
		'wp_delete_page',

		// Categorie e tag.
		'wp_list_categories',
		'wp_list_tags',
		'wp_create_category',
		'wp_create_tag',
		'wp_add_post_terms',
		'wp_delete_category',
		'wp_delete_tag',
		'wp_delete_term',

		// Media.
		'wp_list_media',
		'wp_get_media',
		'wp_upload_media', // Comprende wp_upload_media_from_url.
		'wp_update_media',
		'wp_edit_media_image',
		'wp_delete_media',

		// Plugin, temi e core.
		'wp_list_plugins',
		'wp_list_plugin_updates',
		'wp_list_themes',
		'wp_update_plugin',
		'wp_update_theme',
		'wp_update_core',
		'wp_install_plugin',
		'wp_activate_plugin',
		'wp_deactivate_plugin',
		'wp_uninstall_plugin',
		'wp_delete_plugin',

		// Utenti.
		'wp_list_users',
		'wp_get_user',
		'wp_delete_user',

		// Sito e diagnostica.
		'wp_get_site_settings',
		'wp_get_site_health',
		'wp_get_error_log',
		'wp_get_easy_mcp_diagnostics',
		'wp_list_disabled_tools',
		'wp_send_feedback',
		'wp_rest_routes',
		'wp_rest_read',
		'wp_rest_write',
		'wp_privileged_search_replace_run',

		// SEO: title, description (lo slug con wp_update_post / wp_update_page).
		'wp_rm_get_post_seo',
		'wp_rm_update_post_seo',
		'wp_yoast_get_post_seo',
		'wp_yoast_update_post_seo',

		// Site Kit: Search Console.
		'wp_sitekit_get_status',
		'wp_sitekit_gsc_query_performance',

		// WP Rocket: nessuno strumento di Easy MCP AI; la cache si svuota con POST /cache/svuota di questo plugin.
	);

	/** Strumenti spenti che passerebbero per inizio del nome di un modello in BASE. */
	const SPENTI = array(
		'wp_get_post_full',
		'wp_get_post_blocks',
		'wp_get_post_meta',
		'wp_get_post_types',
		'wp_get_post_statuses',
		'wp_get_page_layout',
		'wp_update_post_blocks',
		'wp_update_post_meta',
		'wp_update_page_layout',
		'wp_delete_post_meta',
		'wp_delete_term_meta',
		'wp_update_theme_mod',
		'wp_get_user_meta',
		'wp_delete_user_meta',
	);

	/** Strumenti che chiedono conferma (Require approval). Tutti gli altri: senza conferma. Riapplicato ogni ora. */
	const CONFERMA = array(
		'wp_delete_post',
		'wp_delete_page',
		'wp_delete_category',
		'wp_delete_tag',
		'wp_delete_term',
		'wp_delete_media',
		'wp_install_plugin',
		'wp_activate_plugin',
		'wp_deactivate_plugin',
		'wp_uninstall_plugin',
		'wp_delete_plugin',
		'wp_delete_user',
		'wp_privileged_search_replace_run',
	);

	// Impostazioni interne di Easy MCP AI (2.4.0): choices[strumento] = { enabled, requireApproval }.
	const OPZIONE_POLICY = 'easy_mcp_ai_tool_policy';
	const HOOK_CONFERME  = 'rc_claude_strumenti_conferme';

	/** Nomi brevi per le richieste più comuni. */
	const ALIAS = array(
		'elementor' => 'wp_ability_elementor_*',
		'imagify'   => 'wp_ability_imagify_*',
		'divi'      => 'wp_divi_*',
	);

	/* ---------- Ciclo di vita ---------- */

	public static function avvia() {
		add_action( 'init', array( __CLASS__, 'assicura_mu' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'registra_rest' ) );
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'rinnova_eccezioni' ), 10, 3 );
		add_action( self::HOOK_CONFERME, array( __CLASS__, 'applica_conferme' ) );
		add_action( 'init', array( __CLASS__, 'assicura_cron' ) );
	}

	public static function assicura_cron() {
		if ( ! wp_next_scheduled( self::HOOK_CONFERME ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, 'hourly', self::HOOK_CONFERME );
		}
	}

	public static function attivazione() {
		self::assicura_mu();
		self::assicura_cron();
	}

	/** Disattivando il plugin, Easy MCP AI torna alle sue impostazioni. L'opzione resta per la riattivazione. */
	public static function disattivazione() {
		self::cancella_mu();
		wp_clear_scheduled_hook( self::HOOK_CONFERME );
	}

	public static function disinstallazione() {
		self::cancella_mu();
		wp_clear_scheduled_hook( self::HOOK_CONFERME );
		delete_option( self::OPZIONE );
	}

	/* ---------- Conferme (Require approval) ---------- */

	/**
	 * Riporta le conferme di Easy MCP AI al default: CONFERMA con conferma, tutti gli altri senza.
	 * Tocca solo requireApproval; se il formato non è quello atteso non scrive niente.
	 * Restituisce l'esito, salvato anche nell'opzione del modulo per /info.
	 */
	public static function applica_conferme() {
		$c = self::config();
		if ( empty( $c['attivo'] ) ) {
			return self::esito_conferme( $c, 'saltato', 'Modulo spento su questo sito.' );
		}

		$policy = get_option( self::OPZIONE_POLICY );
		if ( ! is_array( $policy ) || ! isset( $policy['choices'] ) || ! is_array( $policy['choices'] ) ) {
			return self::esito_conferme( $c, 'formato_sconosciuto', 'easy_mcp_ai_tool_policy non ha il formato atteso: nessuna modifica.' );
		}
		foreach ( $policy['choices'] as $scelta ) {
			if ( ! is_array( $scelta ) ) {
				return self::esito_conferme( $c, 'formato_sconosciuto', 'Una voce di choices non è un array: nessuna modifica.' );
			}
		}

		$cambiati = array();
		$nomi     = array_unique( array_merge( array_keys( $policy['choices'] ), self::CONFERMA ) );
		foreach ( $nomi as $nome ) {
			$voluto = in_array( $nome, self::CONFERMA, true );
			$scelta = isset( $policy['choices'][ $nome ] ) ? $policy['choices'][ $nome ] : array();
			$attuale = ! empty( $scelta['requireApproval'] );
			if ( $attuale !== $voluto || ! array_key_exists( 'requireApproval', $scelta ) ) {
				$scelta['requireApproval']   = $voluto;
				$policy['choices'][ $nome ] = $scelta;
				if ( $attuale !== $voluto ) {
					$cambiati[] = $nome . ( $voluto ? ' → conferma' : ' → senza conferma' );
				}
			}
		}

		if ( $cambiati ) {
			update_option( self::OPZIONE_POLICY, $policy );
		}
		return self::esito_conferme( $c, 'ok', count( $cambiati ) . ' cambiati', $cambiati );
	}

	private static function esito_conferme( array $c, $stato, $messaggio, $cambiati = array() ) {
		$esito          = array(
			'stato'     => $stato,
			'messaggio' => $messaggio,
			'cambiati'  => $cambiati,
			'il'        => wp_date( 'd/m/Y H:i:s' ),
		);
		$c['conferme']  = $esito;
		update_option( self::OPZIONE, $c, true );
		return $esito;
	}

	/* ---------- Opzione ---------- */

	private static function config() {
		$c = get_option( self::OPZIONE );
		$c = is_array( $c ) ? $c : array();
		return wp_parse_args(
			$c,
			array(
				'attivo'     => false,
				'base'       => array(),
				'spenti'     => array(),
				'eccezioni'  => array(), // modello => array( 'creata' => ts, 'ultimo' => ts ).
				'inattivita' => self::INATTIVITA,
				'tetto'      => self::TETTO,
				'versione'   => '',
			)
		);
	}

	/** Salva la configurazione, con la lista di default del plugin sempre aggiornata. */
	private static function salva( array $c ) {
		$c['base']       = array_values( array_unique( self::BASE ) );
		$c['spenti']     = array_values( array_unique( self::SPENTI ) );
		$c['inattivita'] = self::INATTIVITA;
		$c['tetto']      = self::TETTO;
		$c['versione']   = RC_CLAUDE_VERSIONE;
		$c['eccezioni']  = self::eccezioni_valide( $c['eccezioni'] );
		update_option( self::OPZIONE, $c, true );
		return $c;
	}

	private static function scadenza( array $e ) {
		return min( (int) $e['ultimo'] + self::INATTIVITA, (int) $e['creata'] + self::TETTO );
	}

	/** Solo eccezioni ancora valide, nel formato attuale (quelle della 1.3.0, un solo timestamp, scadono). */
	private static function eccezioni_valide( $eccezioni ) {
		$ora   = time();
		$esito = array();
		foreach ( is_array( $eccezioni ) ? $eccezioni : array() as $modello => $e ) {
			if ( is_array( $e ) && isset( $e['creata'], $e['ultimo'] ) && self::scadenza( $e ) > $ora ) {
				$esito[ $modello ] = array( 'creata' => (int) $e['creata'], 'ultimo' => (int) $e['ultimo'] );
			}
		}
		return $esito;
	}

	/* ---------- Rinnovo all'uso ---------- */

	/**
	 * Legge (senza modificarla) ogni chiamata MCP a Easy MCP AI: se Claude usa uno strumento
	 * di un'eccezione, ne sposta la scadenza a 1 ora da adesso (entro il tetto di 24 ore).
	 */
	public static function rinnova_eccezioni( $risultato, $server, $richiesta ) {
		if ( ! $richiesta instanceof WP_REST_Request ) {
			return $risultato;
		}
		$rotta = (string) $richiesta->get_route();
		if ( 0 !== strpos( $rotta, '/easy-mcp-ai/' ) && 0 !== strpos( $rotta, '/mcp' ) ) {
			return $risultato;
		}

		$c = self::config();
		if ( empty( $c['attivo'] ) || empty( $c['eccezioni'] ) ) {
			return $risultato;
		}

		$nomi = self::strumenti_chiamati( $richiesta->get_json_params() );
		if ( ! $nomi ) {
			return $risultato;
		}

		$ora      = time();
		$cambiato = false;
		foreach ( self::eccezioni_valide( $c['eccezioni'] ) as $modello => $e ) {
			foreach ( $nomi as $nome ) {
				if ( self::corrisponde( $modello, $nome ) && $ora - (int) $e['ultimo'] >= 60 ) {
					$c['eccezioni'][ $modello ]['ultimo'] = $ora;
					$cambiato                             = true;
				}
			}
		}
		if ( $cambiato ) {
			self::salva( $c );
		}
		return $risultato;
	}

	/** Nomi degli strumenti in una richiesta JSON-RPC "tools/call" (anche in blocco). */
	private static function strumenti_chiamati( $corpo ) {
		if ( ! is_array( $corpo ) ) {
			return array();
		}
		$messaggi = isset( $corpo['method'] ) ? array( $corpo ) : $corpo;
		$nomi     = array();
		foreach ( $messaggi as $m ) {
			if ( is_array( $m ) && 'tools/call' === ( $m['method'] ?? '' ) && isset( $m['params']['name'] ) && is_string( $m['params']['name'] ) ) {
				$nomi[] = $m['params']['name'];
			}
		}
		return $nomi;
	}

	/** Stessa logica di Easy MCP AI: modello glob, oppure inizio del nome. */
	private static function corrisponde( $modello, $nome ) {
		return fnmatch( $modello, $nome ) || 0 === strpos( $nome, rtrim( $modello, '*' ) );
	}

	/* ---------- File in mu-plugins ---------- */

	private static function percorso_mu() {
		return trailingslashit( WPMU_PLUGIN_DIR ) . self::FILE_MU;
	}

	/** Crea o aggiorna il file in mu-plugins e allinea la lista di default dopo un aggiornamento del plugin. */
	public static function assicura_mu() {
		$c = self::config();
		if ( RC_CLAUDE_VERSIONE !== $c['versione'] ) {
			self::salva( $c );
			self::applica_conferme();
		}

		$percorso = self::percorso_mu();
		if ( is_readable( $percorso ) && false !== strpos( (string) file_get_contents( $percorso ), "RC_CLAUDE_MU_VERSIONE', '" . self::VERSIONE_MU . "'" ) ) {
			return true;
		}
		if ( ! wp_mkdir_p( WPMU_PLUGIN_DIR ) ) {
			return false;
		}
		return false !== @file_put_contents( $percorso, self::contenuto_mu(), LOCK_EX );
	}

	private static function cancella_mu() {
		$percorso = self::percorso_mu();
		if ( is_file( $percorso ) ) {
			@unlink( $percorso );
		}
	}

	private static function contenuto_mu() {
		return <<<'PHP'
<?php
/**
 * Plugin Name: RC AI Claude Connettore – Strumenti
 * Description: Strumenti Easy MCP AI disponibili per Claude. Creato e gestito da RC AI Claude Connettore (modulo Strumenti): non modificare. Per tornare alle impostazioni di Easy MCP AI cancella questo file.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RC_CLAUDE_MU_VERSIONE', '2' );

( static function () {
	$c = get_option( 'rc_claude_strumenti' );
	if ( ! is_array( $c ) || empty( $c['attivo'] ) || empty( $c['base'] ) || ! is_array( $c['base'] ) ) {
		return;
	}

	$inattivita = isset( $c['inattivita'] ) ? (int) $c['inattivita'] : 3600;
	$tetto      = isset( $c['tetto'] ) ? (int) $c['tetto'] : 86400;
	$ora        = time();
	$modelli    = array_map( 'strval', $c['base'] );
	$eccezioni  = array();
	foreach ( ( isset( $c['eccezioni'] ) && is_array( $c['eccezioni'] ) ) ? $c['eccezioni'] : array() as $modello => $e ) {
		if ( is_array( $e ) && isset( $e['creata'], $e['ultimo'] ) && min( (int) $e['ultimo'] + $inattivita, (int) $e['creata'] + $tetto ) > $ora ) {
			$modelli[]   = (string) $modello;
			$eccezioni[] = (string) $modello;
		}
	}

	if ( ! defined( 'EASY_MCP_AI_ALLOWED_TOOL_PATTERNS' ) ) {
		define( 'EASY_MCP_AI_ALLOWED_TOOL_PATTERNS', implode( ',', array_unique( $modelli ) ) );
	}

	// Spenti uno per uno, salvo quelli accesi da un'eccezione.
	$spenti = array();
	foreach ( ( isset( $c['spenti'] ) && is_array( $c['spenti'] ) ) ? $c['spenti'] : array() as $nome ) {
		$nome   = (string) $nome;
		$acceso = false;
		foreach ( $eccezioni as $m ) {
			if ( fnmatch( $m, $nome ) || 0 === strpos( $nome, rtrim( $m, '*' ) ) ) {
				$acceso = true;
				break;
			}
		}
		if ( ! $acceso ) {
			$spenti[] = $nome . '=off';
		}
	}
	if ( $spenti && ! defined( 'EASY_MCP_AI_TOOLS' ) ) {
		define( 'EASY_MCP_AI_TOOLS', implode( ',', $spenti ) );
	}
} )();

PHP;
	}

	/* ---------- REST ---------- */

	public static function registra_rest() {
		RC_Claude_Rest::registra( '/strumenti', 'GET', array( __CLASS__, 'rest_stato' ) );
		RC_Claude_Rest::registra(
			'/strumenti',
			'POST',
			array( __CLASS__, 'rest_imposta' ),
			array(
				'attivo'   => array(
					'type'        => 'boolean',
					'description' => 'Accende o spegne il filtro degli strumenti su questo sito.',
				),
				'aggiungi' => array(
					'type'        => 'string',
					'description' => 'Su richiesta: elementor, imagify, divi oppure modelli separati da virgola (es. wp_ability_elementskit_*). Scade 1 ora dopo l\'ultimo utilizzo, al massimo dopo 24 ore.',
				),
				'rimuovi'  => array(
					'type'        => 'string',
					'description' => 'Spegne subito eccezioni: stessi nomi di aggiungi, oppure * per tutte.',
				),
			)
		);
		RC_Claude_Rest::registra(
			'/strumenti/easy-mcp',
			'GET',
			array( __CLASS__, 'rest_opzioni_easy_mcp' ),
			array(
				'nome' => array(
					'type'        => 'string',
					'description' => 'Nome esatto di un\'opzione easy_mcp*: ne restituisce il valore completo (segreti oscurati).',
				),
			)
		);
	}

	public static function rest_stato() {
		return rest_ensure_response( self::stato() );
	}

	public static function rest_imposta( WP_REST_Request $richiesta ) {
		$c = self::config();

		if ( null !== $richiesta->get_param( 'attivo' ) ) {
			$c['attivo'] = (bool) $richiesta->get_param( 'attivo' );
		}

		$rimuovi = self::modelli( $richiesta->get_param( 'rimuovi' ) );
		if ( in_array( '*', $rimuovi, true ) ) {
			$c['eccezioni'] = array();
		} else {
			foreach ( $rimuovi as $m ) {
				unset( $c['eccezioni'][ $m ] );
			}
		}

		$ora = time();
		foreach ( self::modelli( $richiesta->get_param( 'aggiungi' ) ) as $m ) {
			if ( '*' === $m ) {
				continue; // Tutto acceso: non previsto, si spegne il filtro con attivo=false.
			}
			$c['eccezioni'][ $m ] = array( 'creata' => $ora, 'ultimo' => $ora );
		}

		self::salva( $c );
		$mu       = self::assicura_mu();
		$conferme = self::applica_conferme();

		$stato              = self::stato();
		$stato['mu_ok']     = $mu;
		$stato['conferme']  = $conferme;
		$stato['messaggio'] = 'Salvato. Vale dalla prossima connessione di Claude (nuova chat).';
		return rest_ensure_response( $stato );
	}

	/** Modelli validi da una stringa separata da virgole; traduce gli alias (elementor, imagify, divi). */
	private static function modelli( $testo ) {
		if ( ! is_string( $testo ) || '' === trim( $testo ) ) {
			return array();
		}
		$esito = array();
		foreach ( explode( ',', $testo ) as $m ) {
			$m = trim( $m );
			$a = strtolower( $m );
			if ( isset( self::ALIAS[ $a ] ) ) {
				$m = self::ALIAS[ $a ];
			}
			if ( '' !== $m && preg_match( '/^[A-Za-z0-9_*?\[\]\-]+$/', $m ) ) {
				$esito[] = $m;
			}
		}
		return array_values( array_unique( $esito ) );
	}

	/** Stato completo, usato anche da /info (in forma breve). */
	public static function stato() {
		$c         = self::config();
		$eccezioni = array();
		foreach ( self::eccezioni_valide( $c['eccezioni'] ) as $m => $e ) {
			$eccezioni[] = array(
				'modello'        => $m,
				'accesa_il'      => RC_Claude_Utilita::data( $e['creata'] ),
				'ultimo_utilizzo' => RC_Claude_Utilita::data( $e['ultimo'] ),
				'scade_il'       => RC_Claude_Utilita::data( self::scadenza( $e ) ),
			);
		}

		return array(
			'attivo'             => (bool) $c['attivo'],
			'mu_plugin_presente' => is_readable( self::percorso_mu() ),
			'consentiti_definiti' => defined( 'EASY_MCP_AI_ALLOWED_TOOL_PATTERNS' ),
			'consentiti'         => defined( 'EASY_MCP_AI_ALLOWED_TOOL_PATTERNS' ) ? constant( 'EASY_MCP_AI_ALLOWED_TOOL_PATTERNS' ) : null,
			'spenti_definiti'    => defined( 'EASY_MCP_AI_TOOLS' ),
			'spenti'             => defined( 'EASY_MCP_AI_TOOLS' ) ? constant( 'EASY_MCP_AI_TOOLS' ) : null,
			'easy_mcp_ai_attivo' => self::easy_mcp_attivo(),
			'modelli_base'       => count( self::BASE ),
			'modelli_spenti'     => count( self::SPENTI ),
			'base'               => array_values( self::BASE ),
			'su_richiesta'       => self::ALIAS,
			'regola'             => 'Eccezioni: scadono 1 ora dopo l\'ultimo utilizzo, al massimo 24 ore dopo l\'accensione.',
			'eccezioni'          => $eccezioni,
			'con_conferma'       => array_values( self::CONFERMA ),
			'conferme'           => isset( $c['conferme'] ) ? $c['conferme'] : null,
			'prossime_conferme'  => RC_Claude_Utilita::data( wp_next_scheduled( self::HOOK_CONFERME ), 'd/m/Y H:i' ),
			'nota'               => 'Conferme (Require approval) riportate al default ogni ora. Le modifiche agli strumenti valgono dalla prossima connessione di Claude.',
		);
	}

	/* ---------- Opzioni di Easy MCP AI (sola lettura, per diagnosi) ---------- */

	const SEGRETI = '/token|secret|key|password|pass|json|hash|salt|credential|client/i';

	/**
	 * Elenco delle opzioni easy_mcp_ai* (nome, autoload, dimensione, tipo, chiavi, anteprima),
	 * oppure il valore completo di una sola opzione con ?nome=. Valori segreti oscurati.
	 */
	public static function rest_opzioni_easy_mcp( WP_REST_Request $richiesta ) {
		global $wpdb;

		$nome = (string) $richiesta->get_param( 'nome' );
		if ( '' !== $nome ) {
			if ( 0 !== strpos( $nome, 'easy_mcp' ) ) {
				return new WP_Error( 'rc_nome', 'Solo opzioni che iniziano con easy_mcp.', array( 'status' => 400 ) );
			}
			return rest_ensure_response(
				array(
					'nome'   => $nome,
					'valore' => self::oscura( get_option( $nome, null ), $nome ),
				)
			);
		}

		$righe = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT option_name, autoload, LENGTH(option_value) AS byte FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name",
				$wpdb->esc_like( 'easy_mcp' ) . '%'
			),
			ARRAY_A
		);

		$esito = array();
		foreach ( (array) $righe as $r ) {
			$valore = get_option( $r['option_name'] );
			$voce   = array(
				'nome'     => $r['option_name'],
				'autoload' => $r['autoload'],
				'byte'     => (int) $r['byte'],
				'tipo'     => gettype( $valore ),
			);
			if ( is_array( $valore ) ) {
				$voce['chiavi'] = array_slice( array_map( 'strval', array_keys( $valore ) ), 0, 40 );
			} elseif ( ! preg_match( self::SEGRETI, $r['option_name'] ) ) {
				$voce['anteprima'] = mb_substr( is_scalar( $valore ) ? (string) $valore : '', 0, 120 );
			}
			$esito[] = $voce;
		}

		return rest_ensure_response( array( 'opzioni' => $esito, 'totale' => count( $esito ) ) );
	}

	/** Oscura i valori sotto chiavi che sembrano segreti, ricorsivamente. */
	private static function oscura( $valore, $chiave = '' ) {
		if ( is_array( $valore ) ) {
			$esito = array();
			foreach ( $valore as $k => $v ) {
				$esito[ $k ] = self::oscura( $v, (string) $k );
			}
			return $esito;
		}
		if ( is_object( $valore ) ) {
			return self::oscura( (array) $valore, $chiave );
		}
		if ( '' !== $chiave && preg_match( self::SEGRETI, $chiave ) && null !== $valore && '' !== $valore && ! is_bool( $valore ) ) {
			return '[OSCURATO]';
		}
		return $valore;
	}

	/** Per /info: senza l'elenco completo. */
	public static function stato_breve() {
		$s = self::stato();
		unset( $s['base'], $s['consentiti'], $s['spenti'], $s['su_richiesta'], $s['nota'], $s['con_conferma'] );
		return $s;
	}

	private static function easy_mcp_attivo() {
		$attivi = (array) get_option( 'active_plugins', array() );
		foreach ( $attivi as $p ) {
			if ( 0 === strpos( (string) $p, 'easy-mcp-ai/' ) ) {
				return true;
			}
		}
		return false;
	}
}

RC_Claude_Loader::registra(
	array(
		'id'          => 'strumenti',
		'classe'      => 'RC_Claude_Strumenti',
		'versione'    => '1.1',
		'descrizione' => 'Strumenti Easy MCP AI visibili a Claude: lista di default comune; su richiesta Elementor, Imagify, Divi (1 ora dall\'ultimo utilizzo, max 24 ore). Spento per default.',
		'indirizzi'   => array( 'GET /strumenti', 'POST /strumenti {attivo, aggiungi, rimuovi}', 'GET /strumenti/easy-mcp?nome=' ),
	)
);
