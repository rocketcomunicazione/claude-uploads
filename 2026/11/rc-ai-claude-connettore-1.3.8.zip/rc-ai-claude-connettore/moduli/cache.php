<?php
/**
 * Modulo Cache: stato in tempo reale e pulizia completa della cache WP Rocket con verifica.
 * Stessi passaggi di "Svuota tutte le pagine" di RC Site Manager più quelli del pulsante
 * "Cancella la cache" di WP Rocket, senza dipendere da RC Site Manager.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Cache {

	const LIMITE_SEC = 10;

	// Cartelle che la pulizia completa deve svuotare.
	const CARTELLE_PULITE = array( 'wp-rocket', 'min', 'used-css', 'busting' );

	const UA = array(
		'desktop' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.0.0 Safari/537.36',
		'mobile'  => 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15A372 Safari/604.1',
	);

	/* ---------- Ciclo di vita ---------- */

	public static function avvia() {
		add_action( 'rest_api_init', array( __CLASS__, 'registra_rest' ) );
	}

	public static function registra_rest() {
		RC_Claude_Rest::registra(
			'/cache',
			'GET',
			array( __CLASS__, 'rest_stato' ),
			array(
				'dal' => array(
					'type'        => 'integer',
					'default'     => 0,
					'description' => 'Timestamp Unix: conta i file più vecchi di questo momento.',
				),
			)
		);

		RC_Claude_Rest::registra(
			'/cache/svuota',
			'POST',
			array( __CLASS__, 'rest_svuota' ),
			array(
				'piano_b' => array(
					'type'        => 'boolean',
					'default'     => false,
					'description' => 'Se dopo la pulizia restano pagine HTML vecchie in cache/wp-rocket, le cancella. Non tocca mai wp-rocket-config.',
				),
			)
		);
	}

	/* ---------- Stato della cache (tempo reale) ---------- */

	public static function rest_stato( WP_REST_Request $richiesta ) {
		return rest_ensure_response( self::stato( (int) $richiesta->get_param( 'dal' ) ) );
	}

	public static function stato( $dal = 0 ) {
		$base     = RC_Claude_Utilita::wp_content() . '/cache';
		$scadenza = microtime( true ) + self::LIMITE_SEC;

		$esito = array(
			'wp_rocket_attivo' => defined( 'WP_ROCKET_VERSION' ),
			'letto_il'         => wp_date( 'd/m/Y H:i:s' ),
			'dal'              => RC_Claude_Utilita::data( $dal ),
			'esiste'           => is_dir( $base ),
			'byte'             => 0,
			'dimensione'       => RC_Claude_Utilita::dimensione( 0 ),
			'file'             => 0,
			'file_vecchi'      => 0,
			'cartelle'         => array(),
			'completo'         => true,
		);

		if ( ! $esito['esiste'] ) {
			return $esito;
		}

		$voci = @scandir( $base );
		foreach ( is_array( $voci ) ? $voci : array() as $nome ) {
			if ( '.' === $nome || '..' === $nome ) {
				continue;
			}
			$percorso = $base . '/' . $nome;
			if ( ! is_dir( $percorso ) || is_link( $percorso ) ) {
				continue;
			}
			$m = self::analizza( $percorso, $dal, $scadenza );

			$esito['cartelle'][] = array(
				'nome'        => $nome,
				'byte'        => $m['byte'],
				'dimensione'  => RC_Claude_Utilita::dimensione( $m['byte'] ),
				'file'        => $m['file'],
				'file_vecchi' => $m['vecchi'],
				'piu_vecchio' => RC_Claude_Utilita::data( $m['min'] ),
				'piu_recente' => RC_Claude_Utilita::data( $m['max'] ),
			);
			$esito['byte']        += $m['byte'];
			$esito['file']        += $m['file'];
			$esito['file_vecchi'] += $m['vecchi'];
			if ( ! $m['completo'] ) {
				$esito['completo'] = false;
				break;
			}
		}

		$esito['dimensione'] = RC_Claude_Utilita::dimensione( $esito['byte'] );
		return $esito;
	}

	/** Peso, numero di file, file più vecchi di $dal, data minima e massima. Segnaposto esclusi. */
	private static function analizza( $dir, $dal, $scadenza ) {
		$r = array( 'byte' => 0, 'file' => 0, 'vecchi' => 0, 'min' => 0, 'max' => 0 );

		$r['completo'] = RC_Claude_Utilita::scorri(
			$dir,
			$scadenza,
			static function ( $f ) use ( &$r, $dal ) {
				if ( RC_Claude_Utilita::e_segnaposto( $f->getFilename() ) ) {
					return;
				}
				$t          = $f->getMTime();
				$r['byte'] += $f->getSize();
				$r['file']++;
				$r['min'] = $r['min'] ? min( $r['min'], $t ) : $t;
				$r['max'] = max( $r['max'], $t );
				if ( $dal && $t < $dal ) {
					$r['vecchi']++;
				}
			}
		);

		return $r;
	}

	/* ---------- Pulizia completa ---------- */

	public static function rest_svuota( WP_REST_Request $richiesta ) {
		global $wpdb;

		if ( ! function_exists( 'rocket_clean_domain' ) ) {
			return rest_ensure_response(
				array(
					'ok'        => false,
					'messaggio' => 'WP Rocket non attivo o funzione rocket_clean_domain non disponibile.',
				)
			);
		}

		$inizio = time();
		$passi  = array();

		// 1. Come il pulsante "Cancella la cache" di WP Rocket: minificati e cache busting, poi tutte le pagine.
		if ( function_exists( 'rocket_clean_minify' ) ) {
			rocket_clean_minify();
			$passi[] = 'rocket_clean_minify';
		}
		if ( function_exists( 'rocket_clean_cache_busting' ) ) {
			rocket_clean_cache_busting();
			$passi[] = 'rocket_clean_cache_busting';
		}
		rocket_clean_domain();
		$passi[] = 'rocket_clean_domain';

		// 2. Used CSS: tabella e file (ormai orfani: nessuna pagina in cache li usa più).
		$tabella    = $wpdb->prefix . 'wpr_rucss_used_css';
		$righe_ucss = null;
		if ( $tabella === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $tabella ) ) ) ) {
			$righe_ucss = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM `' . esc_sql( $tabella ) . '`' );
			$wpdb->query( 'TRUNCATE TABLE `' . esc_sql( $tabella ) . '`' );
			$passi[] = 'used_css_tabella_svuotata';
		}
		$file_ucss = self::cancella( RC_Claude_Utilita::wp_content() . '/cache/used-css', 'used-css', 0, false );
		$passi[]   = 'used_css_file_cancellati';

		// 3. Avviso di WP Rocket "Uno o più plugin sono stati abilitati o disabilitati".
		$avviso  = self::chiudi_avviso_plugin();
		$passi[] = 'avviso_wp_rocket';

		// 4. Storico PageSpeed di RC Site Manager, solo se presente (nessuna dipendenza).
		if ( function_exists( 'rc_sm_pagespeed_clear_all_history' ) ) {
			rc_sm_pagespeed_clear_all_history();
			$passi[] = 'storico_pagespeed_rc_sm';
		}

		// 5. Rigenera la home, desktop e mobile.
		$home = rtrim( home_url(), '/' );
		foreach ( self::UA as $ua ) {
			wp_remote_get(
				$home,
				array(
					'timeout'   => 30,
					'blocking'  => false,
					'sslverify' => false,
					'headers'   => array( 'User-Agent' => $ua ),
				)
			);
		}
		$passi[] = 'home_rigenerata';

		// 6. Verifica: nelle cartelle pulite nessun file più vecchio dell'inizio (segnaposto esclusi).
		clearstatcache();
		$verifica = self::stato( $inizio );
		$html     = self::cartella( $verifica, 'wp-rocket' );

		$piano_b = null;
		if ( $html && $html['file_vecchi'] > 0 && $richiesta->get_param( 'piano_b' ) ) {
			$piano_b = self::cancella( RC_Claude_Utilita::wp_content() . '/cache/wp-rocket', 'wp-rocket', $inizio, true );
			$passi[] = 'piano_b';
			clearstatcache();
			$verifica = self::stato( $inizio );
		}

		$vecchi    = array();
		$dettaglio = array();
		foreach ( self::CARTELLE_PULITE as $nome ) {
			$c = self::cartella( $verifica, $nome );
			if ( $c && $c['file_vecchi'] > 0 ) {
				$vecchi[ $nome ] = $c['file_vecchi'];
				$dettaglio[]     = $c['file_vecchi'] . ' in ' . $nome;
			}
		}
		$totale_vecchi = array_sum( $vecchi );

		return rest_ensure_response(
			array(
				'ok'               => 0 === $totale_vecchi && $verifica['completo'],
				'messaggio'        => 0 === $totale_vecchi
					? 'Cache svuotata: nessun file più vecchio della pulizia.'
					: 'Cache NON svuotata del tutto: file più vecchi della pulizia (' . implode( ', ', $dettaglio ) . ').',
				'inizio'           => RC_Claude_Utilita::data( $inizio ),
				'passi'            => $passi,
				'used_css_righe'   => $righe_ucss,
				'used_css_file'    => $file_ucss,
				'avviso_wp_rocket' => $avviso,
				'file_vecchi'      => $vecchi,
				'piano_b'          => $piano_b,
				'verifica'         => $verifica,
			)
		);
	}

	/* ---------- Supporto ---------- */

	private static function cartella( $stato, $nome ) {
		foreach ( $stato['cartelle'] as $c ) {
			if ( $nome === $c['nome'] ) {
				return $c;
			}
		}
		return null;
	}

	/**
	 * Cancella i file di una cartella di cache nota (mai cartelle, link o segnaposto).
	 * $prima_di > 0: solo i file più vecchi di quel momento. $solo_html: solo pagine HTML.
	 */
	private static function cancella( $dir, $nome_atteso, $prima_di, $solo_html ) {
		$esito = array( 'cancellati' => 0, 'errori' => 0 );
		if ( ! is_dir( $dir ) || basename( $dir ) !== $nome_atteso ) {
			return $esito;
		}

		$completo = RC_Claude_Utilita::scorri(
			$dir,
			microtime( true ) + self::LIMITE_SEC,
			static function ( $f ) use ( &$esito, $prima_di, $solo_html ) {
				if ( RC_Claude_Utilita::e_segnaposto( $f->getFilename() ) ) {
					return;
				}
				if ( $prima_di && $f->getMTime() >= $prima_di ) {
					return;
				}
				if ( $solo_html && ! preg_match( '/\.html(_gzip|\.gz)?$/', $f->getFilename() ) ) {
					return;
				}
				if ( @unlink( $f->getPathname() ) ) {
					$esito['cancellati']++;
				} else {
					$esito['errori']++;
				}
			}
		);

		$esito['completo'] = $completo;
		return $esito;
	}

	/**
	 * Segna come chiuso l'avviso "rocket_warning_plugin_modification" per ogni amministratore,
	 * come fa WP Rocket con "Cancella la cache" o "Dismiss this notice".
	 */
	private static function chiudi_avviso_plugin() {
		$box    = 'rocket_warning_plugin_modification';
		$utenti = get_users( array( 'role__in' => array( 'administrator' ), 'fields' => 'ID' ) );
		$chiusi = 0;
		foreach ( $utenti as $id ) {
			$boxes = get_user_meta( (int) $id, 'rocket_boxes', true );
			$boxes = is_array( $boxes ) ? $boxes : array();
			if ( ! in_array( $box, $boxes, true ) ) {
				$boxes[] = $box;
				update_user_meta( (int) $id, 'rocket_boxes', $boxes );
				$chiusi++;
			}
		}
		return array( 'amministratori' => count( $utenti ), 'chiusi' => $chiusi );
	}
}

RC_Claude_Loader::registra(
	array(
		'id'          => 'cache',
		'classe'      => 'RC_Claude_Cache',
		'versione'    => '1.1',
		'descrizione' => 'Cache WP Rocket: stato in tempo reale e pulizia completa (pagine, minificati, busting, Used CSS, avviso) con verifica sulla data dei file.',
		'indirizzi'   => array( 'GET /cache?dal=timestamp', 'POST /cache/svuota {piano_b}' ),
	)
);
