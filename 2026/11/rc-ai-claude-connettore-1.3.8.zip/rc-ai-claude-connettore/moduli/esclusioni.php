<?php
/**
 * Modulo Esclusioni: WP Rocket non mette mai in cache gli indirizzi del connettore Easy MCP AI
 * e i documenti di accesso OAuth. Correzione suggerita dalla diagnostica di Easy MCP AI.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class RC_Claude_Esclusioni {

	const OPZIONE = 'rc_claude_esclusioni_versione';

	// Espressioni nel formato di WP Rocket ("Non mettere mai in cache questi URL").
	const URI = array(
		'/wp-json/easy-mcp-ai/(.*)',
		'/.well-known/oauth-(.*)',
		'/.well-known/openid-configuration',
	);

	public static function avvia() {
		add_filter( 'rocket_cache_reject_uri', array( __CLASS__, 'aggiungi' ) );
		add_action( 'admin_init', array( __CLASS__, 'rigenera_se_serve' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'rigenera_se_serve' ) );
	}

	public static function aggiungi( $uri ) {
		$uri = is_array( $uri ) ? $uri : array();
		return array_values( array_unique( array_merge( $uri, self::URI ) ) );
	}

	/** Dopo attivazione o aggiornamento rigenera una volta configurazione e .htaccess di WP Rocket. */
	public static function rigenera_se_serve() {
		if ( RC_CLAUDE_VERSIONE === get_option( self::OPZIONE ) ) {
			return;
		}
		if ( ! function_exists( 'rocket_generate_config_file' ) ) {
			return; // WP Rocket non attivo: riproverà quando lo sarà.
		}
		rocket_generate_config_file();
		if ( function_exists( 'flush_rocket_htaccess' ) ) {
			flush_rocket_htaccess();
		}
		update_option( self::OPZIONE, RC_CLAUDE_VERSIONE, false );
	}

	public static function disattivazione() {
		delete_option( self::OPZIONE );
		remove_filter( 'rocket_cache_reject_uri', array( __CLASS__, 'aggiungi' ) );
		if ( function_exists( 'rocket_generate_config_file' ) ) {
			rocket_generate_config_file();
		}
	}

	public static function disinstallazione() {
		delete_option( self::OPZIONE );
	}

	/** Per /info. */
	public static function stato() {
		$attive = apply_filters( 'rocket_cache_reject_uri', array() );
		return array(
			'wp_rocket_attivo'     => defined( 'WP_ROCKET_VERSION' ),
			'esclusioni_applicate' => array_values( array_intersect( self::URI, is_array( $attive ) ? $attive : array() ) ),
			'config_rigenerata'    => RC_CLAUDE_VERSIONE === get_option( self::OPZIONE ),
		);
	}
}

RC_Claude_Loader::registra(
	array(
		'id'          => 'esclusioni',
		'classe'      => 'RC_Claude_Esclusioni',
		'versione'    => '1.0',
		'descrizione' => 'WP Rocket: non mette in cache /wp-json/easy-mcp-ai/, /.well-known/oauth-* e /.well-known/openid-configuration.',
		'indirizzi'   => array(),
	)
);
