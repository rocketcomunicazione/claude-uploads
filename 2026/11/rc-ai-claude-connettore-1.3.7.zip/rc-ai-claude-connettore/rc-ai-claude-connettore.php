<?php
/**
 * Plugin Name: RC AI Claude Connettore
 * Description: Funzioni che il connettore WordPress standard non offre, per Claude. Moduli: misura reale dello spazio, pulizia completa della cache WP Rocket con verifica, strumenti Easy MCP AI visibili a Claude, esclusione degli indirizzi del connettore dalla cache. Tutto via REST (/wp-json/rc-ai-claude-connettore/v1/), solo per amministratori. Indipendente da altri plugin RC.
 * Version: 1.3.7
 * Author: Rocket Comunicazione
 * Update URI: https://github.com/rocketcomunicazione/rc-ai-claude-connettore
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: rc-ai-claude-connettore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RC_CLAUDE_VERSIONE', '1.3.7' );
define( 'RC_CLAUDE_FILE', __FILE__ );
define( 'RC_CLAUDE_DIR', plugin_dir_path( __FILE__ ) );

require_once RC_CLAUDE_DIR . 'core/utilita.php';
require_once RC_CLAUDE_DIR . 'core/rest.php';
require_once RC_CLAUDE_DIR . 'core/loader.php';
require_once RC_CLAUDE_DIR . 'core/aggiornamenti.php';

RC_Claude_Loader::carica();

register_activation_hook( __FILE__, array( 'RC_Claude_Loader', 'attivazione' ) );
register_deactivation_hook( __FILE__, array( 'RC_Claude_Loader', 'disattivazione' ) );
register_uninstall_hook( __FILE__, array( 'RC_Claude_Loader', 'disinstallazione' ) );
